const express =  require('express')
const router = express.Router();


var book_array=[
    {
        "bookTitle":"Angular for Dummies",
        "author":"Black Couche",
        "genre":"Thriller",
        "description":"That is what newyork",
        "price":150,
        "url":"http://api.randomuser.me/portraits/thumb/men/58.jpg"
    },
    {
        "bookTitle":"NodeJS for Dummies",
        "author":"Black Couche",
        "genre":"Thriller",
        "description":"That is what newyork",
        "price":250,
        "url":"http://api.randomuser.me/portraits/thumb/women/56.jpg"
    },

];


router.get('/',  function (req, res) {

    
    res.render('index',{books:book_array})
    
 
 });

 

module.exports=router;