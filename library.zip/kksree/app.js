const Express = require('express');
const bodyParser = require('body-parser');
var bookRouter = require('./routes/books');
var authorRouter = require('./routes/authors');
const path = require('path');

var app = new Express();


app.use(Express.static(path.join(__dirname,"/public")));
app.set('view engine','ejs');    
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use("/",bookRouter);
app.use("/authors",authorRouter);


app.listen(process.env.PORT||3000,()=>{

    console.log("Listening in port 3000");
});
